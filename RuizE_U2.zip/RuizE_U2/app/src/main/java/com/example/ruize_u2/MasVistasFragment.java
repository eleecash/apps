package com.example.ruize_u2;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

public class MasVistasFragment extends Fragment {
    private EditText entrada;
    private TextView salida;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.mas_vistas, container, false);

        entrada = view.findViewById(R.id.entrada);
        salida = view.findViewById(R.id.salida);

        ImageView button = view.findViewById(R.id.sePulsa0);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sePulsa(v);
            }
        });

        Button boton0 = view.findViewById(R.id.button2);
        boton0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sePulsa0(v);
            }
        });

        return view;
    }

    public void sePulsa(View view) {
        String inputText = entrada.getText().toString().trim();
        if (!inputText.isEmpty()) {
            try {
                float floatValue = Float.parseFloat(inputText);
                salida.setText(String.valueOf(floatValue * 2.0));
            } catch (NumberFormatException e) {
            }
        } else {
        }
    }

    public void sePulsa0(View view) {
        entrada.setText(entrada.getText() + (String) view.getTag());
    }
}