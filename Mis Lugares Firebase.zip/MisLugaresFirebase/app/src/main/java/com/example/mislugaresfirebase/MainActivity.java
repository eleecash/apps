package com.example.mislugaresfirebase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseUser usuario = FirebaseAuth.getInstance().getCurrentUser();

        TextView nombre = findViewById(R.id.nombre);
        nombre.setText(usuario.getDisplayName());

        TextView correo = findViewById(R.id.correo);
        correo.setText(usuario.getEmail());

        TextView proveedor = findViewById(R.id.proveedor);
        proveedor.setText(usuario.getProviderId());

        TextView telefono = findViewById(R.id.telefono);
        telefono.setText(usuario.getPhoneNumber());

        TextView uid = findViewById(R.id.uid);
        uid.setText(usuario.getUid());
    }



}