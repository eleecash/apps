package com.example.mislugares;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.mislugares.Aplicacion;
import com.example.mislugares.Lugar;
import com.example.mislugares.R;
import com.example.mislugares.RepositorioLugares;

import java.text.DateFormat;
import java.util.Date;

public class VistaLugarActivity extends AppCompatActivity {
    private RepositorioLugares lugares;
    private int pos;
    private Lugar lugar;
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.vista_lugar);
        lugares = ((Aplicacion) getApplication()).lugares;
        Bundle extras = getIntent().getExtras();
        pos = extras.getInt("pos", 0);
        lugar = lugares.elemento(pos);
        actualizaVistas();
    }

    public void actualizaVistas() {
        TextView nombre = findViewById(R.id.nombre);
        ImageView logoTipo = findViewById(R.id.logo_tipo);
        TextView tipo = findViewById(R.id.tipo);
        TextView direccion = findViewById(R.id.direccion);
        TextView telefono = findViewById(R.id.telefono);
        TextView url = findViewById(R.id.url);
        TextView comentario = findViewById(R.id.comentario);
        TextView fecha = findViewById(R.id.fecha);
        TextView hora = findViewById(R.id.hora);
        RatingBar valoracion = findViewById(R.id.valoracion);
        nombre.setText(lugar.getNombre());
        logoTipo.setImageResource(lugar.getTipo().getRecurso());
        tipo.setText(lugar.getTipo().getTexto());
        direccion.setText(lugar.getDireccion());
        telefono.setText(Integer.toString(lugar.getTelefono()));
        url.setText(lugar.getUrl());
        comentario.setText(lugar.getComentario());
        fecha.setText(DateFormat.getDateInstance().format(
                new Date(lugar.getFecha())));
        hora.setText(DateFormat.getTimeInstance().format(
                new Date(lugar.getFecha())));
        valoracion.setRating(lugar.getValoracion());
        valoracion.setOnRatingBarChangeListener(
                new RatingBar.OnRatingBarChangeListener() {
                    @Override public void onRatingChanged(RatingBar ratingBar,
                                                          float valor, boolean fromUser) {
                        lugar.setValoracion(valor);
                    }
                });
    }
}