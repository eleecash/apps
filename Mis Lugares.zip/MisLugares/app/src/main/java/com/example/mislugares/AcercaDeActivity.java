package com.example.mislugares;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;

public class AcercaDeActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.acercade);

        MediaPlayer mp;
        mp = MediaPlayer.create(this, R.raw.winx);
        mp.pause();
        int pos = mp.getCurrentPosition();
        mp.seekTo(pos);
        mp.pause();

    }
}

